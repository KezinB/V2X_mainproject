if you are using platformIO use folder named "Sign Language To Speech Conversion 1 ".
if you are using Arduino IDE use folder named "Sign Language To Speech Conversion 2 ".